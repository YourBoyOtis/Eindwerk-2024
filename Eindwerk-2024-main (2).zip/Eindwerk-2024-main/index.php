<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welkom bij BocchiMania</title>
    <link rel="stylesheet" href="styles.css">
    <script src="dark-mode.js" defer></script>
</head>
<body>
    <header>
        <img src="images/logo.png" alt="BocchiManiaLogo">
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Producten</a></li>
                <li><a href="info.php">Informatie</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="login.php">login</a></li>
            </ul>
        </nav>
        <button id="dark-mode-toggle">Donker</button>

    </header>
    <main>
        <section class="hero">
            <h1>Ontdek onze premium gitaren</h1>
            <p>Bezoek onze winkel of bekijk het assortiment online.</p>
            <a href="products.html" class="btn-primary">Bekijk Producten</a>
        </section>
        <section class="features">
            <div class="feature-item">
                <h2>Handgemaakte Kwaliteit</h2>
                <p>Elke gitaar wordt met de hand vervaardigd met oog voor detail. We gebruiken alleen de beste materialen.</p>
            </div>
            <div class="feature-item">
                <h2>Lokale Ambacht</h2>
                <p>Wij steunen lokale ambachtslieden en bevorderen het Nederlandse vakmanschap in de muziekindustrie.</p>
            </div>
            <div class="feature-item">
                <h2>Educatie en Workshops</h2>
                <p>Leer spelen en onderhoud je gitaar met onze professionele workshops en cursussen.</p>
            </div>
        </section>
        <section class="latest-news">
            <h2>Laatste Nieuws</h2>
            <article>
                <h3>Nieuwe Collectie 2024</h3>
                <p>Ontdek onze nieuwste collectie gitaren, beschikbaar vanaf maart 2024. Van klassieke modellen tot moderne elektrische gitaren, er is iets voor elke gitarist.</p>
            </article>
            <article>
                <h3>Workshop Schema's</h3>
                <p>Bekijk de nieuwste schema's voor onze gitaarworkshops en meld je vandaag nog aan. Plaatsen zijn beperkt, dus zorg dat je er snel bij bent!</p>
            </article>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 BocchiMania. Alle rechten voorbehouden.</p>
    </footer>
</body>
</html>