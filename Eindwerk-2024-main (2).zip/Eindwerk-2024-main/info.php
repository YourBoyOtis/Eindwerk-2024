<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gitaarsoorten - BocchiMania</title>
    <link rel="stylesheet" href="styles.css">
    <script src="dark-mode.js" defer></script>
</head>
<body>
    <header>
        <img src="images/logo.png" alt="BocchiManiaLogo">
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Producten</a></li>
                <li><a href="info.php">Informatie</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
        <button id="dark-mode-toggle">Donker</button>
    </header>
    <main>
        <h1>Soorten Gitaren</h1>
        <p>Ontdek de verschillende soorten gitaren die wij aanbieden en vind uit welke het beste bij jouw muzikale stijl past.</p>
        
        <section>
            <h2>Akoestische Gitaren</h2>
            <img src="images/acoustic-guitar.jpg" alt="Akoestische Gitaar">
            <p>Akoestische gitaren zijn perfect voor spelers die een rijk, vol geluid waarderen dat voortkomt uit de natuurlijke resonantie van het instrument. Ze zijn ideaal voor folk, country, en veel popmuziek.</p>
        </section>

        <section>
            <h2>Elektrische Gitaren</h2>
            <img src="images/electric-guitar.jpg" alt="Elektrische Gitaar">
            <p>Elektrische gitaren bieden een breed scala aan geluiden en zijn vaak de keuze voor rock, blues, en metal muzikanten. Door hun elektronische aard kunnen ze worden aangepast met een breed scala aan effecten.</p>
        </section>

        <section>
            <h2>Basgitaren</h2>
            <img src="images/bass-guitar.jpg" alt="Basgitaar">
            <p>Basgitaren leggen de basis voor de ritmesectie van een band. Ze zijn essentieel voor genres als funk, jazz, rock, en pop, door hun diepe, krachtige tonen.</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 BocchiMania. Alle rechten voorbehouden.</p>
    </footer>
</body>
</html>
